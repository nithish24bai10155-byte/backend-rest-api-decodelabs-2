const taskStore = require('../models/taskStore');

// GET /api/tasks — retrieve all tasks
function getTasks(req, res) {
  res.status(200).json({
    count: taskStore.getAll().length,
    data: taskStore.getAll()
  });
}

// GET /api/tasks/:id — retrieve a single task
function getTaskById(req, res) {
  const id = parseInt(req.params.id, 10);
  const task = taskStore.getById(id);

  if (!task) {
    return res.status(404).json({ error: `Task with id ${id} not found` });
  }

  res.status(200).json({ data: task });
}

// POST /api/tasks — create a new task
function createTask(req, res) {
  const { title } = req.body;
  const newTask = taskStore.create(title.trim());

  res.status(201).json({
    message: 'Task created successfully',
    data: newTask
  });
}

module.exports = { getTasks, getTaskById, createTask };
