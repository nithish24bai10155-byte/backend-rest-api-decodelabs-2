// Simple in-memory data store (acts as our "database" for this project)
let tasks = [
  { id: 1, title: 'Learn Express.js', completed: false },
  { id: 2, title: 'Build a REST API', completed: false }
];
let nextId = 3;

module.exports = {
  getAll: () => tasks,
  getById: (id) => tasks.find((t) => t.id === id),
  create: (title) => {
    const newTask = { id: nextId++, title, completed: false };
    tasks.push(newTask);
    return newTask;
  }
};
