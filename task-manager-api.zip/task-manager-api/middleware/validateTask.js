// Validates the request body before a task is created.
// This follows "The Gatekeeper Rule": never trust the client.
function validateTask(req, res, next) {
  const { title } = req.body;

  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    return res.status(400).json({
      error: 'Validation failed',
      details: 'Field "title" is required and must be a non-empty string.'
    });
  }

  next();
}

module.exports = validateTask;
