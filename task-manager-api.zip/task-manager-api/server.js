/**
 * Task Manager API
 * DecodeLabs Full Stack Development — Project 2: Backend API Development
 *
 * A simple, well-structured REST API that demonstrates:
 *  - RESTful endpoint design (GET / POST)
 *  - Request validation ("never trust the client")
 *  - Correct, semantic HTTP status codes
 *  - Clean JSON request/response contracts
 */

const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// ---------------------------------------------
// In-memory "database" (resets on server restart)
// ---------------------------------------------
let tasks = [
  { id: 1, title: 'Design API endpoints', completed: true },
  { id: 2, title: 'Implement validation logic', completed: false },
  { id: 3, title: 'Write documentation', completed: false },
];
let nextId = 4;

// ---------------------------------------------
// Root — simple health check
// ---------------------------------------------
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Task Manager API is running 🚀',
    endpoints: {
      'GET /api/tasks': 'Retrieve all tasks',
      'GET /api/tasks/:id': 'Retrieve a single task by ID',
      'POST /api/tasks': 'Create a new task',
    },
  });
});

// ---------------------------------------------
// GET /api/tasks — retrieve all tasks
// ---------------------------------------------
app.get('/api/tasks', (req, res) => {
  res.status(200).json({
    success: true,
    count: tasks.length,
    data: tasks,
  });
});

// ---------------------------------------------
// GET /api/tasks/:id — retrieve a single task
// ---------------------------------------------
app.get('/api/tasks/:id', (req, res) => {
  const id = Number(req.params.id);
  const task = tasks.find((t) => t.id === id);

  if (!task) {
    return res.status(404).json({
      success: false,
      error: `Task with id ${id} not found`,
    });
  }

  res.status(200).json({ success: true, data: task });
});

// ---------------------------------------------
// POST /api/tasks — create a new task (with validation)
// ---------------------------------------------
app.post('/api/tasks', (req, res) => {
  const { title, completed } = req.body;

  // --- Basic data validation (the "Gatekeeper Rule") ---
  if (!title || typeof title !== 'string' || title.trim().length === 0) {
    return res.status(400).json({
      success: false,
      error: 'Field "title" is required and must be a non-empty string.',
    });
  }

  if (completed !== undefined && typeof completed !== 'boolean') {
    return res.status(400).json({
      success: false,
      error: 'Field "completed" must be a boolean if provided.',
    });
  }

  const newTask = {
    id: nextId++,
    title: title.trim(),
    completed: completed ?? false,
  };

  tasks.push(newTask);

  res.status(201).json({
    success: true,
    message: 'Task created successfully',
    data: newTask,
  });
});

// ---------------------------------------------
// 404 handler for unknown routes
// ---------------------------------------------
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Route not found' });
});

// ---------------------------------------------
// Start server
// ---------------------------------------------
app.listen(PORT, () => {
  console.log(`✅ Task Manager API running on http://localhost:${PORT}`);
});

module.exports = app;
