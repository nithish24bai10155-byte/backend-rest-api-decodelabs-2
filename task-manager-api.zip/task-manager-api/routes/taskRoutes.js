const express = require('express');
const router = express.Router();
const { getTasks, getTaskById, createTask } = require('../controllers/taskController');
const validateTask = require('../middleware/validateTask');

router.get('/', getTasks);
router.get('/:id', getTaskById);
router.post('/', validateTask, createTask);

module.exports = router;
